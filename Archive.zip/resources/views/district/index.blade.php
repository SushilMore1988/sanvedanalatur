<x-auth-layout>
    <x-slot name="page_title">District</x-slot>

    <x-slot name="style">

    </x-slot>

    <x-slot name="javascript">

    </x-slot>

    @livewire('district')
    
</x-auth-layout>