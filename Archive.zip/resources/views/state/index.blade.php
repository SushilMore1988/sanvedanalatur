<x-auth-layout>
    <x-slot name="page_title">States</x-slot>

    <x-slot name="style">

    </x-slot>

    <x-slot name="javascript">

    </x-slot>

    @livewire('state')
    
</x-auth-layout>