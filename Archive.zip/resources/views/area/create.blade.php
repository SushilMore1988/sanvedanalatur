<x-auth-layout>
    <x-slot name="page_title">Create New Area</x-slot>
    <x-slot name="style"></x-slot>
    <x-slot name="javascript"></x-slot>
</x-auth-layout>