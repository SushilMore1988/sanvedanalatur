<x-auth-layout>
    <x-slot name="page_title">City</x-slot>

    <x-slot name="style">

    </x-slot>

    <x-slot name="javascript">

    </x-slot>

    @livewire('village')

</x-auth-layout>
