<x-auth-layout>
    <x-slot name="page_title">Taluka</x-slot>

    <x-slot name="style">

    </x-slot>

    <x-slot name="javascript">

    </x-slot>

    @livewire('taluka')

</x-auth-layout>
