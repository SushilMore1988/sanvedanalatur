<x-auth-layout>
    <x-slot name="page_title">Admin List</x-slot>
    <x-slot name="style"></x-slot>
    <x-slot name="javascript"></x-slot>

    @livewire('admin')
</x-auth-layout>